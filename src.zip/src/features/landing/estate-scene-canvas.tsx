'use client';

// src/features/landing/estate-scene-canvas.tsx
//
// The actual Three.js content (section 8 of the redesign mandate): a
// bright, simplified architectural estate — a handful of light-gray box
// "buildings" of varying height on a pale ground plane, with cyan/blue
// "data lines" arcing between them to represent
// Bank → Payment → House → Tenant → Collection Status.
//
// Deliberately NOT photorealistic (no textures, no heavy geometry, no
// OrbitControls exposed to the user — the camera drifts on its own so
// this reads as an ambient illustration, not an interactive toy). Loaded
// only via the dynamic(..., { ssr: false }) wrapper in hero-section.tsx,
// and only when prefers-reduced-motion is NOT set.

import { Canvas, useFrame } from '@react-three/fiber';
import { useMemo, useRef } from 'react';
import * as THREE from 'three';

const BUILDING_LAYOUT = [
  { x: -3.2, z: -0.5, height: 1.4, width: 1.1 },
  { x: -1.6, z: 0.6, height: 2.2, width: 1.3 },
  { x: 0, z: -0.8, height: 1.8, width: 1.2 },
  { x: 1.7, z: 0.4, height: 2.6, width: 1.1 },
  { x: 3.3, z: -0.4, height: 1.5, width: 1.2 },
];

function Buildings() {
  const group = useRef<THREE.Group>(null);

  useFrame((_, delta) => {
    if (group.current) group.current.rotation.y += delta * 0.05; // slow ambient drift, not user-driven
  });

  return (
    <group ref={group}>
      {BUILDING_LAYOUT.map((b, i) => (
        <mesh key={i} position={[b.x, b.height / 2, b.z]} castShadow receiveShadow>
          <boxGeometry args={[b.width, b.height, b.width]} />
          <meshStandardMaterial color={i % 2 === 0 ? '#EAF2F5' : '#F4F8FA'} roughness={0.9} metalness={0} />
        </mesh>
      ))}
      {/* Window accents — thin emissive cyan strips, restrained (section 6/8: lights, not neon) */}
      {BUILDING_LAYOUT.map((b, i) => (
        <mesh key={`glow-${i}`} position={[b.x, b.height * 0.65, b.z + b.width / 2 + 0.01]}>
          <planeGeometry args={[b.width * 0.6, 0.12]} />
          <meshBasicMaterial color="#48CAE4" transparent opacity={0.5} />
        </mesh>
      ))}
    </group>
  );
}

function DataArcs() {
  const points = useMemo(() => {
    const curve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-3.2, 0.2, -0.5),
      new THREE.Vector3(-1, 1.6, 0.2),
      new THREE.Vector3(1.7, 0.2, 0.4),
      new THREE.Vector3(3.3, 1.2, -0.4),
    ]);
    return curve.getPoints(60);
  }, []);

  const geometry = useMemo(() => new THREE.BufferGeometry().setFromPoints(points), [points]);

  return (
    <line>
      <primitive object={geometry} attach="geometry" />
      <lineBasicMaterial color="#00B4D8" transparent opacity={0.55} linewidth={1} />
    </line>
  );
}

function Ground() {
  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow>
      <planeGeometry args={[20, 20]} />
      <meshStandardMaterial color="#F7FBFC" />
    </mesh>
  );
}

export function EstateSceneCanvas() {
  return (
    <Canvas shadows camera={{ position: [0, 3.2, 7.5], fov: 42 }} dpr={[1, 1.5]} gl={{ antialias: true, alpha: true }}>
      <color attach="background" args={['#F0FBFD']} />
      <ambientLight intensity={0.9} />
      <directionalLight position={[4, 6, 3]} intensity={1.1} castShadow shadow-mapSize={[1024, 1024]} />
      <Ground />
      <Buildings />
      <DataArcs />
      <fog attach="fog" args={['#F0FBFD', 8, 18]} />
    </Canvas>
  );
}
