'use client';

import { useRouter } from 'next/navigation';
import { openWorkspace } from '@/lib/navigation/workspace';
import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Card, Button, Stack, TextField, Alert, Dialog, DialogTitle, DialogContent, DialogActions, Chip, Typography,
} from '@mui/material';
import { Layers, Plus } from 'lucide-react';
import { PageHeader } from '@/components/layout/page-header';
import { DataTable, type DataTableColumn } from '@/components/data-display/data-table';
import { houseTypesApi, type HouseType, type CreateHouseTypeInput } from '@/lib/api/house-types';
import { formatCents } from '@/lib/formatting/currency';
import { ApiError } from '@/lib/api/client';
import { useSession } from '@/features/auth/session-context';
import { permissions } from '@/lib/permissions/permissions';
import { useConnectivity } from '@/lib/sync/connectivity';

export default function HouseTypesPage() {
  const router = useRouter();
  const queryClient = useQueryClient();
  const { user } = useSession();
  const canManage = user ? permissions.canManageHouses(user.role) : false;
  const connectivity = useConnectivity();
  const canReach = connectivity.state === 'online' || connectivity.state === 'syncing' || connectivity.state === 'sync-error';
  const [createOpen, setCreateOpen] = useState(false);
  const [editing, setEditing] = useState<HouseType | null>(null);

  const { data, isLoading, error } = useQuery({
    queryKey: ['house-types', true],
    queryFn: () => houseTypesApi.list(true),
  });

  const columns: DataTableColumn<HouseType>[] = [
    { key: 'name', header: 'Name', render: (t) => (
        <span style={{ fontWeight: 600, cursor: 'pointer' }} onClick={() => openWorkspace('houseType', t._id, router)}>{t.name}</span>
      ) },
    { key: 'rent', header: 'Default rent', render: (t) => formatCents(t.defaultRentCents ?? 0) },
    { key: 'houses', header: 'Houses', render: (t) => t.houseCount ?? 0 },
    {
      key: 'status',
      header: 'Status',
      render: (t) => (
        <Chip size="small" label={t.isActive ? 'Active' : 'Inactive'} color={t.isActive ? 'success' : 'default'} variant="outlined" />
      ),
    },
    {
      key: 'actions',
      header: '',
      align: 'right',
      render: (t) => (canManage ? <Button size="small" onClick={() => setEditing(t)}>Edit</Button> : null),
    },
  ];

  return (
    <>
      <PageHeader
        title="House Types"
        description="Classify units. Defaults apply to new houses only — history is never rewritten."
        actions={
          canManage ? (
            <Button variant="contained" startIcon={<Plus size={16} />} onClick={() => setCreateOpen(true)} disabled={!canReach}>
              New type
            </Button>
          ) : null
        }
      />
      <Card>
        <DataTable
          columns={columns}
          rows={data}
          rowKey={(t) => t._id}
          isLoading={isLoading}
          error={error}
          emptyIcon={Layers}
          emptyTitle="No house types yet"
          emptyDescription="Create types so new houses can inherit default rent and billing."
        />
      </Card>
      {createOpen && (
        <HouseTypeDialog
          open={createOpen}
          onClose={() => setCreateOpen(false)}
          onSaved={() => {
            setCreateOpen(false);
            queryClient.invalidateQueries({ queryKey: ['house-types'] });
          }}
        />
      )}
      {editing && (
        <HouseTypeDialog
          open={!!editing}
          initial={editing}
          onClose={() => setEditing(null)}
          onSaved={() => {
            setEditing(null);
            queryClient.invalidateQueries({ queryKey: ['house-types'] });
          }}
        />
      )}
    </>
  );
}

function HouseTypeDialog({
  open,
  onClose,
  onSaved,
  initial,
}: {
  open: boolean;
  onClose: () => void;
  onSaved: () => void;
  initial?: HouseType;
}) {
  const [name, setName] = useState(initial?.name ?? '');
  const [description, setDescription] = useState(initial?.description ?? '');
  const [rentKes, setRentKes] = useState(initial ? String((initial.defaultRentCents ?? 0) / 100) : '');
  const [dueDay, setDueDay] = useState(initial?.defaultDueDay ? String(initial.defaultDueDay) : '5');
  const [formError, setFormError] = useState<string | null>(null);

  const mutation = useMutation({
    mutationFn: async () => {
      const defaultRentCents = Math.round(Number(rentKes || 0) * 100);
      if (!name.trim()) throw new Error('Name is required');
      const payload: CreateHouseTypeInput = {
        name: name.trim(),
        description: description.trim() || undefined,
        defaultRentCents,
        defaultDueDay: dueDay ? Number(dueDay) : undefined,
        defaultBilling:
          defaultRentCents > 0
            ? [{ chargeType: 'RENT', description: 'Rent', amountCents: defaultRentCents, dueDay: dueDay ? Number(dueDay) : undefined }]
            : [],
      };
      if (initial) return houseTypesApi.update(initial._id, payload);
      return houseTypesApi.create(payload);
    },
    onSuccess: () => onSaved(),
    onError: (err) =>
      setFormError(err instanceof ApiError ? err.message : err instanceof Error ? err.message : 'Unable to save'),
  });

  const deactivate = useMutation({
    mutationFn: () => houseTypesApi.deactivate(initial!._id),
    onSuccess: () => onSaved(),
    onError: (err) => setFormError(err instanceof ApiError ? err.message : 'Unable to deactivate'),
  });

  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="xs">
      <DialogTitle>{initial ? 'Edit house type' : 'New house type'}</DialogTitle>
      <DialogContent>
        <Stack spacing={2} sx={{ mt: 1 }}>
          {formError && <Alert severity="error">{formError}</Alert>}
          <TextField label="Name" value={name} onChange={(e) => setName(e.target.value)} required autoFocus />
          <TextField label="Description" value={description} onChange={(e) => setDescription(e.target.value)} multiline minRows={2} />
          <TextField label="Default rent (KES)" type="number" value={rentKes} onChange={(e) => setRentKes(e.target.value)} />
          <TextField label="Default due day (1–28)" type="number" value={dueDay} onChange={(e) => setDueDay(e.target.value)} inputProps={{ min: 1, max: 28 }} />
          {initial && (
            <Typography variant="caption" color="text.secondary">
              Used by {initial.houseCount ?? 0} house(s). Changing defaults does not rewrite past charges.
            </Typography>
          )}
        </Stack>
      </DialogContent>
      <DialogActions>
        {initial?.isActive && (
          <Button color="warning" onClick={() => deactivate.mutate()} disabled={deactivate.isPending}>
            Deactivate
          </Button>
        )}
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" disabled={!name.trim() || mutation.isPending} onClick={() => { setFormError(null); mutation.mutate(); }}>
          {mutation.isPending ? 'Saving…' : 'Save'}
        </Button>
      </DialogActions>
    </Dialog>
  );
}
