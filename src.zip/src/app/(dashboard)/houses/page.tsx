'use client';

import { useRouter } from 'next/navigation';
import { openWorkspace } from '@/lib/navigation/workspace';

import { useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  Card,
  Button,
  Stack,
  TextField,
  MenuItem,
  Select,
  Alert,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Typography,
  Chip,
  Box,
} from '@mui/material';
import { Home, Plus, Search } from 'lucide-react';
import { PageHeader } from '@/components/layout/page-header';
import { DataTable, type DataTableColumn } from '@/components/data-display/data-table';
import { DetailDrawer } from '@/components/ui/detail-drawer';
import { FreshnessBadge } from '@/components/data-display/freshness-badge';
import { useCachedQuery } from '@/hooks/use-cached-query';
import { houseTypesApi } from '@/lib/api/house-types';
import { housesApi, type ChargeType } from '@/lib/api/houses';
import { formatAmount } from '@/lib/formatting/currency';
import { useVisibleEstates } from '@/features/estates/use-visible-estates';
import { useSession } from '@/features/auth/session-context';
import { permissions } from '@/lib/permissions/permissions';
import { ApiError } from '@/lib/api/client';
import { useConnectivity } from '@/lib/sync/connectivity';
import { ErrorState } from '@/components/feedback/error-state';
import type { House } from '@/types/api';

export default function HousesPage() {
  const router = useRouter();
  const { user } = useSession();
  const { estates } = useVisibleEstates();
  const { data: houseTypes } = useQuery({
    queryKey: ['house-types'],
    queryFn: () => houseTypesApi.list(true),
  });
  const queryClient = useQueryClient();

  const [estateId, setEstateId] = useState<string>('');
  const [status, setStatus] = useState<string>('');
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<House | null>(null);
  const [createOpen, setCreateOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [billingOpen, setBillingOpen] = useState(false);
  const [houseTypeFilter, setHouseTypeFilter] = useState<string>('');

  // estateId is deliberately NOT sent to the backend — house.service.js#list
  // never reads it (see lib/api/houses.ts). It's applied here, client-side,
  // as an honest narrowing of whatever the server already scoped and returned.
  const identity = user ? `${user.clientId}:${user.email}` : 'anon';
  const { data, freshness, cachedAt, isLoading, error } = useCachedQuery(
    `${identity}:houses:list:${status}:${search}:${houseTypeFilter}:${estateId}`,
    ['houses', identity, { status, search, houseTypeFilter, estateId }],
    () => housesApi.list({ status: status || undefined, search: search || undefined, houseTypeId: houseTypeFilter && houseTypeFilter !== '__none__' ? houseTypeFilter : undefined, estateId: estateId || undefined })
  );

  const filteredItems = useMemo(() => {
    let items = data?.items ?? [];
    if (estateId) items = items.filter((h) => h.estateId === estateId);
    if (houseTypeFilter === '__none__') items = items.filter((h) => !h.houseTypeId);
    return items;
  }, [data, estateId, houseTypeFilter]);

  const canManage = user ? permissions.canManageHouses(user.role) : false;

  const columns: DataTableColumn<House>[] = [
    { key: 'houseNumber', header: 'House', render: (h) => (
        <span style={{ fontWeight: 600, cursor: 'pointer' }} onClick={() => openWorkspace('house', h._id, router)}>{h.houseNumber}</span>
      ) },
    { key: 'estate', header: 'Estate', render: (h) => estates?.find((e) => e._id === h.estateId)?.name ?? '—' },
    { key: 'type', header: 'House type', render: (h) => h.houseType?.name || (h.houseTypeId ? '—' : 'Unclassified') },
    { key: 'rent', header: 'Monthly Rent', align: 'right', render: (h) => formatAmount(h.monthlyRent) },
    {
      key: 'status',
      header: 'Status',
      render: (h) => <Chip size="small" label={h.status} color={h.status === 'occupied' ? 'success' : 'default'} variant="outlined" />,
    },
  ];

  return (
    <>
      <PageHeader
        title="Houses"
        description="Every property unit under your accessible estates"
        actions={
          canManage && (
            <Button variant="contained" startIcon={<Plus size={16} />} onClick={() => setCreateOpen(true)}>
              New House
            </Button>
          )
        }
      />

      <Card sx={{ p: 2, mb: 2 }}>
        <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5}>
          <TextField
            size="small"
            placeholder="Search house number…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            InputProps={{ startAdornment: <Search size={16} style={{ marginRight: 8, opacity: 0.5 }} /> }}
            fullWidth
          />
          <Select size="small" displayEmpty value={estateId} onChange={(e) => setEstateId(e.target.value)} sx={{ minWidth: 160 }}>
            <MenuItem value="">All estates</MenuItem>
            {estates?.map((e) => (
              <MenuItem key={e._id} value={e._id}>
                {e.name}
              </MenuItem>
            ))}
          </Select>
          <Select size="small" displayEmpty value={status} onChange={(e) => setStatus(e.target.value)} sx={{ minWidth: 140 }}>
            <MenuItem value="">Any status</MenuItem>
            <MenuItem value="occupied">Occupied</MenuItem>
            <MenuItem value="vacant">Vacant</MenuItem>
          </Select>
          <Select size="small" displayEmpty value={houseTypeFilter} onChange={(e) => setHouseTypeFilter(e.target.value)} sx={{ minWidth: 160 }}>
            <MenuItem value="">All house types</MenuItem>
            <MenuItem value="__none__">Unclassified</MenuItem>
            {(houseTypes ?? []).map((ht) => (
              <MenuItem key={ht._id} value={ht._id}>{ht.name}</MenuItem>
            ))}
          </Select>
        </Stack>
      </Card>

      <Card>
        {freshness !== 'live' && (
          <Box sx={{ p: 1.5, pb: 0 }}>
            <FreshnessBadge freshness={freshness} cachedAt={cachedAt} />
          </Box>
        )}
        <DataTable
          columns={columns}
          rows={filteredItems}
          rowKey={(h) => h._id}
          isLoading={isLoading}
          error={error}
          emptyIcon={Home}
          emptyTitle="No houses found"
          emptyDescription="Try clearing your filters, or add the first house for this estate."
          onRowClick={(h) => setSelected(h)}
          renderMobileCard={(h) => (
            <Card variant="outlined" sx={{ p: 2 }} onClick={() => setSelected(h)}>
              <Stack direction="row" justifyContent="space-between">
                <Typography fontWeight={600}>House {h.houseNumber}</Typography>
                <Chip size="small" label={h.status} color={h.status === 'occupied' ? 'success' : 'default'} variant="outlined" />
              </Stack>
              <Typography variant="body2" color="text.secondary">
                {formatAmount(h.monthlyRent)} / month
              </Typography>
            </Card>
          )}
        />
      </Card>

      <DetailDrawer
        open={Boolean(selected)}
        onClose={() => setSelected(null)}
        title={selected ? `House ${selected.houseNumber}` : ''}
        subtitle={estates?.find((e) => e._id === selected?.estateId)?.name}
        actions={
          canManage &&
          selected && (
            <Stack direction="row" spacing={1}>
              <Button size="small" variant="outlined" onClick={() => setEditOpen(true)}>
                Edit house
              </Button>
              <Button size="small" variant="outlined" onClick={() => setBillingOpen(true)}>
                Billing config
              </Button>
            </Stack>
          )
        }
      >
        {selected && (
          <Stack spacing={2}>
            <DetailRow label="Monthly Rent" value={formatAmount(selected.monthlyRent)} />
            <DetailRow label="Status" value={selected.status} />
            <DetailRow label="Due day" value={selected.dueDay ? `Day ${selected.dueDay} of month` : '—'} />
            {selected.paymentReferences && selected.paymentReferences.length > 0 && (
              <DetailRow label="Alternate payment references" value={selected.paymentReferences.join(', ')} />
            )}
          </Stack>
        )}
      </DetailDrawer>

      {canManage && selected && (
        <EditHouseDialog
          open={editOpen}
          onClose={() => setEditOpen(false)}
          house={selected}
          onSaved={(updated) => {
            setSelected(updated);
            queryClient.invalidateQueries({ queryKey: ['houses'] });
          }}
        />
      )}

      {canManage && (
        <CreateHouseDialog
          open={createOpen}
          onClose={() => setCreateOpen(false)}
          estates={estates ?? []}
          onCreated={() => queryClient.invalidateQueries({ queryKey: ['houses'] })}
        />
      )}

      {canManage && selected && (
        <HouseBillingDialog
          open={billingOpen}
          onClose={() => setBillingOpen(false)}
          house={selected}
        />
      )}
    </>
  );
}

function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <Box>
      <Typography variant="caption" color="text.secondary">
        {label}
      </Typography>
      <Typography variant="body1">{value}</Typography>
    </Box>
  );
}

function EditHouseDialog({ open, onClose, house, onSaved }: { open: boolean; onClose: () => void; house: House; onSaved: (updated: House) => void }) {
  // Section 6 of this pass: house update via the existing detail-drawer
  // architecture. Only fields house.controller.js#update actually accepts
  // are ever sent — no clientId/estateId ownership fields, since the
  // backend derives those from the authenticated session/existing record,
  // not from client input.
  const { data: houseTypes } = useQuery({
    queryKey: ['house-types', 'edit'],
    queryFn: () => houseTypesApi.list(false),
  });
  const [monthlyRent, setMonthlyRent] = useState(String(house.monthlyRent));
  const [dueDay, setDueDay] = useState(house.dueDay ? String(house.dueDay) : '');
  const [status, setStatus] = useState(house.status);
  const [houseTypeId, setHouseTypeId] = useState(house.houseTypeId ? String(house.houseTypeId) : '');
  const [formError, setFormError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  const mutation = useMutation({
    mutationFn: () =>
      housesApi.update(house._id, {
        monthlyRent: Number(monthlyRent),
        dueDay: dueDay ? Number(dueDay) : undefined,
        status,
        houseTypeId: houseTypeId || null,
      }),
    onSuccess: (updated) => {
      setSaved(true);
      onSaved(updated);
    },
    onError: (err) => setFormError(err instanceof ApiError ? err.message : 'Unable to update house.'),
  });

  const valid = Number(monthlyRent) > 0;

  return (
    <Dialog
      open={open}
      onClose={() => {
        setSaved(false);
        onClose();
      }}
      fullWidth
      maxWidth="xs"
    >
      <DialogTitle>Edit House {house.houseNumber}</DialogTitle>
      <DialogContent>
        <Stack spacing={2} sx={{ mt: 1 }}>
          {formError && <Alert severity="error">{formError}</Alert>}
          {saved && (
            <Alert severity="success" onClose={() => setSaved(false)}>
              House updated.
            </Alert>
          )}
          <Select displayEmpty value={houseTypeId} onChange={(e) => setHouseTypeId(e.target.value)} fullWidth>
            <MenuItem value="">Unclassified</MenuItem>
            {(houseTypes ?? []).map((t) => (
              <MenuItem key={t._id} value={t._id}>{t.name}</MenuItem>
            ))}
          </Select>
          <TextField label="Monthly rent (KES)" type="number" value={monthlyRent} onChange={(e) => setMonthlyRent(e.target.value)} required />
          <TextField label="Due day of month" type="number" value={dueDay} onChange={(e) => setDueDay(e.target.value)} />
          <Select value={status} onChange={(e) => setStatus(e.target.value)}>
            <MenuItem value="vacant">Vacant</MenuItem>
            <MenuItem value="occupied">Occupied</MenuItem>
          </Select>
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button
          onClick={() => {
            setSaved(false);
            onClose();
          }}
        >
          Close
        </Button>
        <Button
          variant="contained"
          disabled={!valid || mutation.isPending}
          onClick={() => {
            setFormError(null);
            mutation.mutate();
          }}
        >
          {mutation.isPending ? 'Saving…' : 'Save changes'}
        </Button>
      </DialogActions>
    </Dialog>
  );
}

function CreateHouseDialog({
  open,
  onClose,
  estates,
  onCreated,
}: {
  open: boolean;
  onClose: () => void;
  estates: { _id: string; name: string }[];
  onCreated: () => void;
}) {
  const { data: houseTypes } = useQuery({
    queryKey: ['house-types', 'active'],
    queryFn: () => houseTypesApi.list(false),
    enabled: open,
  });
  const [estateId, setEstateId] = useState('');
  const [houseNumber, setHouseNumber] = useState('');
  const [houseTypeId, setHouseTypeId] = useState('');
  const [monthlyRent, setMonthlyRent] = useState('');
  const [formError, setFormError] = useState<string | null>(null);

  const selectedType = (houseTypes ?? []).find((t) => t._id === houseTypeId);

  const onTypeChange = (id: string) => {
    setHouseTypeId(id);
    const t = (houseTypes ?? []).find((x) => x._id === id);
    if (t && t.defaultRentCents > 0 && !monthlyRent) {
      setMonthlyRent(String(Math.round(t.defaultRentCents) / 100));
    }
  };

  const valid = useMemo(
    () => estateId && houseNumber && Number(monthlyRent) > 0,
    [estateId, houseNumber, monthlyRent]
  );

  const mutation = useMutation({
    mutationFn: () =>
      housesApi.create({
        estateId,
        houseNumber,
        monthlyRent: Number(monthlyRent),
        houseTypeId: houseTypeId || undefined,
      }),
    onSuccess: () => {
      onCreated();
      setEstateId('');
      setHouseNumber('');
      setHouseTypeId('');
      setMonthlyRent('');
      onClose();
    },
    onError: (err) => setFormError(err instanceof ApiError ? err.message : 'Unable to create house.'),
  });

  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="xs">
      <DialogTitle>New House</DialogTitle>
      <DialogContent>
        <Stack spacing={2} sx={{ mt: 1 }}>
          {formError && <Alert severity="error">{formError}</Alert>}
          <Select displayEmpty value={estateId} onChange={(e) => setEstateId(e.target.value)}>
            <MenuItem value="" disabled>
              Select estate
            </MenuItem>
            {estates.map((e) => (
              <MenuItem key={e._id} value={e._id}>
                {e.name}
              </MenuItem>
            ))}
          </Select>
          <Select displayEmpty value={houseTypeId} onChange={(e) => onTypeChange(e.target.value)}>
            <MenuItem value="">House type (optional)</MenuItem>
            {(houseTypes ?? []).map((t) => (
              <MenuItem key={t._id} value={t._id}>
                {t.name}
                {t.defaultRentCents > 0 ? ` · default ${Math.round(t.defaultRentCents) / 100} KES` : ''}
              </MenuItem>
            ))}
          </Select>
          {selectedType ? (
            <Typography variant="caption" color="text.secondary">
              Type default is a starting rent only — house rent stays independently editable.
            </Typography>
          ) : null}
          <TextField label="House number" value={houseNumber} onChange={(e) => setHouseNumber(e.target.value)} required />
          <TextField
            label="Monthly rent (KES)"
            type="number"
            value={monthlyRent}
            onChange={(e) => setMonthlyRent(e.target.value)}
            required
          />
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button
          variant="contained"
          disabled={!valid || mutation.isPending}
          onClick={() => {
            setFormError(null);
            mutation.mutate();
          }}
        >
          {mutation.isPending ? 'Creating…' : 'Create'}
        </Button>
      </DialogActions>
    </Dialog>
  );
}


function HouseBillingDialog({ open, onClose, house }: { open: boolean; onClose: () => void; house: House }) {
  const queryClient = useQueryClient();
  const connectivity = useConnectivity();
  const canReach = connectivity.state === 'online' || connectivity.state === 'syncing' || connectivity.state === 'sync-error';
  const [chargeType, setChargeType] = useState<ChargeType>('RENT');
  const [amountKes, setAmountKes] = useState('');
  const [dueDay, setDueDay] = useState(house.dueDay ? String(house.dueDay) : '5');
  const [description, setDescription] = useState('');
  const [formError, setFormError] = useState<string | null>(null);
  const [savedMsg, setSavedMsg] = useState<string | null>(null);

  const { data: configs, isLoading, error, refetch } = useQuery({
    queryKey: ['houses', house._id, 'billing-config'],
    queryFn: () => housesApi.listBillingConfig(house._id),
    enabled: open,
  });

  const save = useMutation({
    mutationFn: () => {
      const amountCents = Math.round(Number(amountKes) * 100);
      if (!Number.isFinite(amountCents) || amountCents < 0) throw new Error('Enter a valid amount');
      return housesApi.upsertBillingConfig(house._id, {
        chargeType,
        amountCents,
        dueDay: dueDay ? Number(dueDay) : undefined,
        description: description || undefined,
        isActive: true,
      });
    },
    onSuccess: () => {
      setSavedMsg('Billing configuration saved (confirmed by server).');
      setFormError(null);
      refetch();
      queryClient.invalidateQueries({ queryKey: ['houses'] });
    },
    onError: (err) => setFormError(err instanceof ApiError ? err.message : 'Unable to save billing configuration.'),
  });

  const deactivate = useMutation({
    mutationFn: (ct: ChargeType) => housesApi.deactivateBillingConfig(house._id, ct),
    onSuccess: () => {
      setSavedMsg('Charge deactivated (confirmed by server).');
      refetch();
    },
    onError: (err) => setFormError(err instanceof ApiError ? err.message : 'Unable to deactivate charge.'),
  });

  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="sm">
      <DialogTitle>Billing — {house.houseNumber}</DialogTitle>
      <DialogContent>
        <Stack spacing={2} sx={{ mt: 1 }}>
          <Typography variant="body2" color="text.secondary">
            House-level charges (RENT, WATER, ELECTRICITY, OTHER). Amounts are stored in cents on the server. The backend is the source of financial truth.
          </Typography>
          {!canReach ? <Alert severity="warning">Saving billing configuration requires connectivity.</Alert> : null}
          {formError ? <Alert severity="error">{formError}</Alert> : null}
          {savedMsg ? <Alert severity="success">{savedMsg}</Alert> : null}
          {error ? <ErrorState error={error} /> : null}
          {isLoading ? <Typography variant="body2">Loading configuration…</Typography> : null}
          {configs && configs.length > 0 ? (
            <Stack spacing={1}>
              {configs.map((c) => (
                <Stack key={c.chargeType} direction="row" justifyContent="space-between" alignItems="center" sx={{ borderBottom: '1px solid', borderColor: 'divider', py: 0.5 }}>
                  <Box>
                    <Typography variant="body2" fontWeight={600}>
                      {c.chargeType}
                      {c.isActive === false ? ' (inactive)' : ''}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      {formatAmount((c.amountCents ?? 0) / 100)} · due day {c.dueDay ?? '—'}
                      {c.description ? ` · ${c.description}` : ''}
                    </Typography>
                  </Box>
                  {c.isActive !== false ? (
                    <Button
                      size="small"
                      color="warning"
                      disabled={!canReach || deactivate.isPending}
                      onClick={() => {
                        setFormError(null);
                        setSavedMsg(null);
                        deactivate.mutate(c.chargeType);
                      }}
                    >
                      Deactivate
                    </Button>
                  ) : null}
                </Stack>
              ))}
            </Stack>
          ) : (
            !isLoading && <Typography variant="body2" color="text.secondary">No house-specific charges configured yet.</Typography>
          )}
          <Typography variant="subtitle2">Add / update charge</Typography>
          <Select value={chargeType} onChange={(e) => setChargeType(e.target.value as ChargeType)} fullWidth>
            <MenuItem value="RENT">RENT</MenuItem>
            <MenuItem value="WATER">WATER</MenuItem>
            <MenuItem value="ELECTRICITY">ELECTRICITY</MenuItem>
            <MenuItem value="OTHER">OTHER</MenuItem>
          </Select>
          <TextField label="Amount (KES)" value={amountKes} onChange={(e) => setAmountKes(e.target.value)} type="number" inputProps={{ min: 0, step: '0.01' }} fullWidth required />
          <TextField label="Due day (1–28)" value={dueDay} onChange={(e) => setDueDay(e.target.value)} type="number" inputProps={{ min: 1, max: 28 }} fullWidth />
          <TextField label="Description (optional)" value={description} onChange={(e) => setDescription(e.target.value)} fullWidth />
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Close</Button>
        <Button
          variant="contained"
          disabled={!canReach || save.isPending || !amountKes}
          onClick={() => {
            setFormError(null);
            setSavedMsg(null);
            save.mutate();
          }}
        >
          {!canReach ? 'Offline' : save.isPending ? 'Saving…' : 'Save charge'}
        </Button>
      </DialogActions>
    </Dialog>
  );
}
