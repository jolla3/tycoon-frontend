import type { Metadata } from 'next';
import { LegalDocument } from '@/components/legal/legal-document';
import { termsOfServiceContent } from '@/content/terms-of-service';
import { appConfig } from '@/config/app';

export const metadata: Metadata = {
  title: `Terms of Service · ${appConfig.name}`,
  description: 'Terms of Service for the property management platform operated by JOMUGIT CONSULTING LIMITED.',
};

export default function TermsPage() {
  return <LegalDocument content={termsOfServiceContent} />;
}
