import type { Metadata } from 'next';
import { LegalDocument } from '@/components/legal/legal-document';
import { privacyPolicyContent } from '@/content/privacy-policy';
import { appConfig } from '@/config/app';

export const metadata: Metadata = {
  title: `Privacy Policy · ${appConfig.name}`,
  description: 'Privacy Policy for the property management platform operated by JOMUGIT CONSULTING LIMITED.',
};

export default function PrivacyPage() {
  return <LegalDocument content={privacyPolicyContent} />;
}
